=== Color My Posts ===
Author URI: http://remicorson/
Plugin URI: http://remicorson.com/color-my-posts
Contributors: corsonr
Donate link: http://remicorson.com/
Tags: Remi Corson, corsonr, customization, colors, themes, administration, admin
Requires at least: 3.0
Tested up to: 3.5
Stable Tag: 0.1

This plugin allows you to style WordPress posts in the administration depending on many criteria.

== Description ==

This plugin allows you to style WordPress posts in the administration depending on many criteria:

1. Post Status
2. Post Format
3. Post ID
4. Post Categories
5. Post Types
6. Post Tags
7. Author
8. Atom

If you have suggestions or bugfixes for the plugin, please report them on [my website](https://remicorson.com).

The construction of this plugin is explained [here](http://www.wpexplorer.com/coloring-posts-wordpress-admin).

There's a premium version of the plugin that integrates full admin options using color picker, [get it here](http://codecanyon.net/item/color-my-posts-pro/3653526?ref=corsonr)

== Installation ==

1. Activate the plugin
2. Edit color-my-posts.php
3. place your own colors

== Screenshots ==

1. Screenshot 1

== Changelog ==

= 0.1 =

* First release!

== Upgrade Notice ==

= 0.1 =

* First release!